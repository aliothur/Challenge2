<?php
class Satellite_Test implements Satellite_Interface
{
	private $future;

	public function getName()
	{
		return 'Test';
	}

	public function getActual()
	{
		return 0;
	}

	public function getMaxFuture()
	{
	

		return $this->future;
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		
		echo 'END '.$this->getName().": $start - $end<br>";
	}
}