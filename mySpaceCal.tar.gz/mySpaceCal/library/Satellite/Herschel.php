<?php
class Satellite_Herschel implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'Herschel';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		//Get the revolutions number
		$client = new Zend_Http_Client('http://herschel.esac.esa.int/observing/ScheduleReport.html'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('/<tr class="browseRow2"><td class="browseItemName">(?P<OD>[0-9]+)<\/td>/', $response, $matches);
		$this->actual=min($matches['OD']);
		$this->future=max($matches['OD']);
		
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";
		
		$client = new Zend_Http_Client('http://herschel.esac.esa.int/observing/ScheduleReport.html'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('#<tr class="browseRow[12]"><td class="browseItemName">(?P<rev>[0-9]+)</td><td class="browseItemName">(?P<name>[^<]+)</td>'.
		'<td class="browseItemName">(?P<ra>[-0-9dmhs.]+)</td><td class="browseItemName">(?P<dec>[-0-9dmhs.]+)</td><td class="browseItemName">[^<]*</td>'.
		'<td class="browseItemName">[^<]*</td><td class="browseItemName">(?P<dur>[0-9]+)</td><td class="browseItemName">(?P<start>[0-9TZ.\-: ]+)</td>'.
		'<td class="browseItemName">(?P<id>[0-9]+)</td><td class="browseItemName">[^<]*</td></tr>#'
							,$response,$matches,PREG_SET_ORDER);
		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$matches=array_reverse($matches);
		foreach($matches as $data)
		{
			$satName = $satellites->getSatelliteId($this->getName());
			$revolution = $data['rev'];
			$startTime = $data['start'];
			$endTime = date('Y-m-d\TH:i:s\Z',strtotime($data['start'])+$data['dur']);//$data['start']+;
			$source = $data['name'];
			$ra = $data['ra'];
			$dec = $data['dec'];
			if(preg_match('/^([0-9]+)[h: ]([0-9]+)[m: ]([0-9]+)\.([0-9]+)[s]?$/',$ra,$out))
				$ra=$out[1].":".$out[2].":".$out[3].".".$out[4];
			elseif(preg_match('/^([0-9]+.[0-9]+[d]?)$/',$ra,$out))
				$ra=$out[1];
			else
				$ra="";
			
			if(preg_match('/^([-+])([0-9]+)[d ]([0-9]+)[m ]([0-9]+)\.([0-9]+)[s]?$/',$dec,$out))
				$dec=$out[1].$out[2].":".$out[3].":".$out[4].".".$out[5];
			elseif(preg_match('/^([0-9]+.[0-9]+[d]?)$/',$dec,$out))			
				$dec=$out[1];
			else
				$dec="";
			unset($out);
			$obs = $data['id'];
			$id = $obs.'-'.$revolution;
				if($id!='-')
				{
					echo "--------> $obs-$revolution<br>";
					$events->addEvent($satName, $id, $startTime, $endTime, $source, $revolution, $ra, $dec);
				}

		

			}
		

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}