<?php
class Satellite_HST implements Satellite_Interface
{
	private $future;

	public function getName()
	{
		return 'HST';
	}

	public function getActual()
	{
		return 0;
	}

	public function getMaxFuture()
	{
	

		return $this->future;
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		
		echo 'END '.$this->getName().": $start - $end<br>";
	}
}