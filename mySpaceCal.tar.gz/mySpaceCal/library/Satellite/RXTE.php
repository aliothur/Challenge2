<?php
class Satellite_RXTE implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'RXTE';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		//Get the revolutions number
// 		$client = new Zend_Http_Client('http://heasarc.gsfc.nasa.gov/docs/xte/SOF/Schedules/index.php', array(
// 			'maxredirects' => 0,
// 			'timeout'      => 30));
// 		$response = $client->request('GET');
        $fp=fopen('http://heasarc.gsfc.nasa.gov/docs/xte/SOF/Schedules/index.php',"r");

        $response = '';
        while($line=stream_get_line($fp,65535))
        {
            $response .= $line;
        }
        fclose($fp);

		preg_match('/RXTE\s+Mission\s+Week\s+([0-9]+),\s+Starting/', $response, $matches);
		$this->actual = $matches[1];

		$fp = TRUE;
		$this->future = $this->actual;
		while($fp)
		{
			$this->future++;
			$fp=@fopen('http://heasarc.gsfc.nasa.gov/docs/xte/SOF/sts/Wk'.vsprintf("%03s",$this->future).'.txt',"r");
		}
		$this->future--;
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$satName = $satellites->getSatelliteId($this->getName());
		for($revolution = $start; $revolution <= $end; $revolution++)
		{
			$fp=@fopen('http://heasarc.gsfc.nasa.gov/docs/xte/SOF/sts/Wk'.vsprintf("%03s",$revolution).'.txt',"r");

			if($fp)
			{
				//Reads all the file
				$salir = FALSE;
				while (!$salir) {
					//2009:282:00:00:00 497664006 OBSERVATION 94336-01-33-01 START
					$reg = '/(\d{4}:\d{1,3}:\d{1,2}:\d{1,2}:\d{1,2})\s+\d+ OBSERVATION\s+([\d-]+)\s+START/';
					while(($line = fgets($fp)) && (preg_match($reg, $line, $matches) == 0)){}

					if(preg_match($reg, $line, $matches) > 0) {
						$start_time = $matches[1];
						$obsId = $matches[2];
						unset($matches);

						//   SOURCE: PKS_2155-304
						$reg = '/SOURCE:\s+(.+)/';
						while(($line = fgets($fp)) && (preg_match($reg, $line, $matches) == 0)){}
                        if($line == FALSE)
                            throw new Exception('Error updating '.$this->getName().', SOURCE line not found.');
						$target = $matches[1];
						unset($matches);

						//   TARGET: RA=329.709991 DEC=-30.230000 ROLL_BIAS=-9.6 SLEW_RATE=6.0
						$reg = '/TARGET:\s+RA=(\d+\.\d+),?\s+DEC=(-?\d+\.\d+)/';
						while(($line = fgets($fp)) && (preg_match($reg, $line, $matches) == 0)){}
                        if($line == FALSE)
                            throw new Exception('Error updating '.$this->getName().', TARGET line not found.');
						$ra = $matches[1];
						$dec = $matches[2];
						unset($matches);

						// 2009:282:00:29:00 497665746 OBSERVATION 94336-01-33-01 END
						//$reg = '/(\d{4}:\d{1,3}:\d{1,2}:\d{1,2}:\d{1,2}) \d+ OBSERVATION ([\d-]+) END/';
						$reg = '/(\d{4}:\d{1,3}:\d{1,2}:\d{1,2}:\d{1,2})\s+\d+\s+OBSERVATION\s+'.$obsId.'\s+END/';
						while(($line = fgets($fp)) && (preg_match($reg, $line, $matches) == 0)){}
                        if($line == FALSE)
                            throw new Exception('Error updating '.$this->getName().', END line not found.');
						$end_time = $matches[1];
						unset($matches);

						$start_time_a = strptime($start_time, '%Y:%j:%T');
						$end_time_a = strptime($end_time, '%Y:%j:%T');
						$start_time = ($start_time_a[tm_year]+1900).'-'.vsprintf("%02s", $start_time_a[tm_mon]+1).'-'.vsprintf("%02s", $start_time_a[tm_mday]).'T'.vsprintf("%02s", $start_time_a[tm_hour]).':'.vsprintf("%02s",$start_time_a[tm_min]).':'.vsprintf("%02s",$start_time_a[tm_sec]).'Z';
						$end_time = ($end_time_a[tm_year]+1900).'-'.vsprintf("%02s", $end_time_a[tm_mon]+1).'-'.vsprintf("%02s", $end_time_a[tm_mday]).'T'.vsprintf("%02s", $end_time_a[tm_hour]).':'.vsprintf("%02s",$end_time_a[tm_min]).':'.vsprintf("%02s",$end_time_a[tm_sec]).'Z';
						echo "--------> $obsId<br>";
						$events->addEvent($satName, $obsId, $start_time, $end_time, $target, $revolution, $ra, $dec);
					}
					else
						$salir = TRUE;
				}
				fclose($fp);
			}
		}
		echo 'END '.$this->getName().": $start - $end<br>";
	}
}