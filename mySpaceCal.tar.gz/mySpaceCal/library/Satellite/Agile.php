<?php
class Satellite_Agile implements Satellite_Interface
{
	public function getName()
	{
		return 'Agile';
	}

	public function getActual()
	{
		return 0;
	}

	public function getMaxFuture()
	{
		return 0;
	}

	public function update($start, $end)
	{//Full update allways, ignore $start and $end
		echo 'START '.$this->getName().": $start - $end<br>";

		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$satName = $satellites->getSatelliteId($this->getName());

		$fp=@fopen('http://agile.asdc.asi.it/current_pointing.html',"r");

		if($fp)
		{
			$response = '';
			while($line=stream_get_line($fp,65535))
			{
				$response .= $line;
			}
			fclose($fp);

			$reg = "/<tr class=\'riga(?:1|2)hide\'>\n+<td > &nbsp <\/td>\n+<td>([a-zA-Z0-9-+.,\"() ]+)<br>([a-zA-Z0-9-+., ]+)<br><\/td>\n+\s*<td>\s*\d+.\d+\s*<\/td>\n+\s*<td>-?\d+.\d+<\/td>\n+\s*<td><div class='rashow'>\s*(\d+.\d+)\s*<\/div><div class='radegshow'>\s*[0-9hms. ]+\s*<\/div><\/td>\n+\s*<td><div class='decshow'>\s*(-?\d+.\d+)\s*<\/div><div class='decdegshow'>\s*[0-9Â°'.\"+ -]+\s*<\/div><\/td>\n+\s*<td align='center'>\s*(\d{4}-\d{2}-\d{2})\s*(\d{2}:\d{2})\s*<\/td>\n+\s*<td  align='center'>\s*(\d{4}-\d{2}-\d{2})\s*(\d{2}:\d{2})\s*<\/td>/";
			preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

			foreach($matches as $match)
			{
				echo "--------> $match[2]<br>";
				$events->addEvent($satName, $match[2], $match[5].'T'.$match[6].'Z', $match[7].'T'.$match[8].'Z', $match[1], 0, $match[3], $match[4]);
			}
		}
		else
		{
			throw new Exception('Error updating '.$this->getName());
		}

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}