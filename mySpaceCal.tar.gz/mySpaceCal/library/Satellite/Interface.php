<?php
interface Satellite_Interface
{
	//Satellite name
	public function getName();

	//Actual revolution/week or similar
	public function getActual();

	//The max revolution/week/... with information available
	public function getMaxFuture();

//	public function init();

	//Add events from $start revolution/week/... to $end revolution/week/...
	public function update($start, $end);

//	public function end();
}