<?php
class Satellite_Integral implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'Integral';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		//Get the revolutions number
		$client = new Zend_Http_Client('http://integral.esac.esa.int/isocweb/schedule.html'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		$client->setParameterGet(array(
			'action'  => 'intro'
		));
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match('/startRevno=([0-9]+)&endRevno=([0-9]+)">Future schedule/', $response, $matches);
		$this->actual = $matches[1] - 1;
		$this->future = $matches[2];
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";
		//Get the csv
		//$handle = fopen("http://integral.esac.esa.int/isocweb/schedule.html?action=schedule&startRevno=$start&endRevno=$end&reverseSort=&format=csv", "r");

		$data = array();
		for($i = $start; $i<=$end; $i += 100)
		{
			if(($i+99) <= $end)
				$end2 = $i+99;
			else
				$end2 = $end;

			$handle = @fopen("http://integral.esac.esa.int/isocweb/schedule.html?action=schedule&startRevno=$i&endRevno=$end2&reverseSort=&format=csv", "r");

			if($handle)
			{
				//Delete the header
				fgetcsv($handle);

				while(($data[] = fgetcsv($handle)) !== FALSE) {}
				fclose($handle);
			}
			else
			{
				throw new Exception('Error updating '.$this->getName());
			}
		}

		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();

		$satName = $satellites->getSatelliteId($this->getName());
		$revolution = $data[0][0];
		$startTime = $data[0][1];
		$endTime = $data[0][2];
		$source = $data[0][4];
		$ra = $data[0][5];
		$dec = $data[0][6];
		$obs = $data[0][9];
		foreach($data as $d)
		{
			if($d[9] == $obs)
			{
				$endTime = $d[2];
			}
			else
			{
				$id = $obs.'-'.$revolution;
				if($id!='-')
				{
					echo "--------> $obs-$revolution<br>";
					$reg = '/(\d{4}-\d{1,2}-\d{1,2}) (\d{1,2}:\d{1,2}:\d{1,2})\./';
					preg_match($reg, $startTime, $matches);
					$startTime = $matches[1].'T'.$matches[2].'Z';
					unset($matches);
					preg_match($reg, $endTime, $matches);
					$endTime = $matches[1].'T'.$matches[2].'Z';
					unset($matches);
					$events->addEvent($satName, $id, $startTime, $endTime, $source, $revolution, $ra, $dec);
				}

				$revolution = $d[0];
				$startTime = $d[1];
				$endTime = $d[2];
				$source = $d[4];
				$ra = $d[5];
				$dec = $d[6];
				$obs = $d[9];

			}
		}

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}