<?php
class Satellite_Spitzer implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'Spitzer';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		//Get the revolutions number
		$client = new Zend_Http_Client('http://ssc.spitzer.caltech.edu/warmmission/scheduling/observinglogs/plan/alltogether.txt'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('/Week (?P<num>[0-9]+) Schedule of Planned Science Observations/', $response, $matches);
		$this->future=max($matches['num']);
		unset($client,$response);
		
$client = new Zend_Http_Client('http://ssc.spitzer.caltech.edu/warmmission/scheduling/observinglogs/obs/alltogether.txt'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		ini_set('memory_limit','128M');
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('/Week (?P<num>[0-9]+) Schedule of Executed Science Observations \(ObsLog\)/', $response, $matches);
		$this->actual=max($matches['num']);
		unset($client,$response);
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";
		ini_set('memory_limit','128M');
		
		$client = new Zend_Http_Client('http://ssc.spitzer.caltech.edu/warmmission/scheduling/observinglogs/plan/alltogether.txt'
				//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		
		$response = $client->request('GET');
		$response=$response->getBody();
		$f=str_replace(array(chr(10).chr(13),chr(13)),array(chr(10),chr(10)),$response);
		unset($response);
		if($start!=0)
		{
		$f=explode('Week '.$start.' Schedule of Planned Science Observations',$f);
		$f=$f[1]."\n";
		}
		preg_match_all(
				"/^(?P<name>[a-zA-Z\ 0-9_\.\+\(\)\-\/]+)[ ]*(?P<ra>[0-9]+:[0-9]+:[0-9]+.".
				"[0-9]+)[ ]*(?P<dec>[+-]?[0-9]+:[0-9]+:[0-9]+.[0-9]+)[ ]+".
				"[a-zA-Z\ 0-9_\.\+\(\)\-\/]+[ ]+[a-zA-Z0-9 _]+[ ]+[0-9]+[ ]+[a-zA-Z_]+[ ]+".
				"(?P<dur>[0-9]+.?[0-9]*)[ ]+(?P<start>[0-9]{4}-[0-9]{2}-[0-9]{2}".
				" [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]+)[ ]+(?P<id>[0-9]+)[ ]+/m"
								,$f,$matches,PREG_SET_ORDER);
								
								
		
		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		foreach($matches as $data)
		{
			$satName = $satellites->getSatelliteId($this->getName());
			$revolution = 0;
			$startTime = date('Y-m-d\TH:i:s\Z',strtotime($data['start']));
			$endTime = date('Y-m-d\TH:i:s\Z',strtotime($data['start'])+(int)($data['dur']*60));
			$source = trim($data['name']);
			$ra = $data['ra'];
			$dec = $data['dec'];
			
			unset($out);
			$obs = $data['id'];
			$id = $obs;
				if($id!='-')
				{
					echo "--------> $obs-$revolution<br>";
					$events->addEvent($satName, $id, $startTime, $endTime, $source, $revolution, $ra, $dec);
				}

		

			}
		

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}