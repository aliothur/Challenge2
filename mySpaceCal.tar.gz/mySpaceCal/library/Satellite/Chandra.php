<?php
class Satellite_Chandra implements Satellite_Interface
{
	private $actual;
	private $future;
	private $dates = array();

	public function getName()
	{
		return 'Chandra';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		$fp=fopen("http://asc.harvard.edu/target_lists/stscheds/index.html","r");

		if($fp)
		{
            $response = '';
			while($line=stream_get_line($fp,65535))
			{
				$response .= $line;
			}
			fclose($fp);

			$reg = "/<!--\s*BEGIN SCHEDULE\s*-->\s*\n\s*<H4\s*ALIGN=CENTER>\s*([a-zA-Z0-9]+)\s*<\/H4>/";
			preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

            $date = strptime($matches[0][1], '%b%d%y');
            $a = ($date[tm_year]+1900).vsprintf("%02s", ($date[tm_mon]+1)).vsprintf("%02s", $date[tm_mday]);

            $date = strptime($matches[1][1], '%b%d%y');
            $b = ($date[tm_year]+1900).vsprintf("%02s", ($date[tm_mon]+1)).vsprintf("%02s", $date[tm_mday]);

            if($a < $b)
            {
                $this->actual = $a;
                $this->future = $b;
            }
            else
            {
                $this->actual = $b;
                $this->future = $a;
            }

			$this->dates[$this->future] = 'http://asc.harvard.edu/target_lists/stscheds/index.html';
			$this->dates[$this->actual] = 'http://asc.harvard.edu/target_lists/stscheds/index.html';
		}
		else
		{
			throw new Exception('Error updating '.$this->getName());
		}
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		$fp=fopen("http://asc.harvard.edu/target_lists/stscheds/oldscheds.html","r");

		if($fp)
		{
            $response = '';
			while($line=stream_get_line($fp,65535))
			{
				$response .= $line;
			}
			fclose($fp);

			$reg = '/<A HREF="([a-zA-Z0-9.]+)">([a-zA-Z0-9]+)<\/A><BR>/';
			preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

			foreach($matches as $match)
			{
				$date = strptime($match[2], '%b%d%y');
				$this->dates[($date[tm_year]+1900).vsprintf("%02s", ($date[tm_mon]+1)).vsprintf("%02s", $date[tm_mday])] = 'http://asc.harvard.edu/target_lists/stscheds/'.$match[1];
			}

			global $filterStart;
			global $filterEnd;

			$filterStart = $start;
			$filterEnd = $end;

			function filterCallbackChandra($var)
			{
				global $filterStart;
				global $filterEnd;

				if($var >= $filterStart && $var <= $filterEnd)
					return true;
				else
					return false;
			}
			$filtered = array_filter(array_keys($this->dates), 'filterCallbackChandra');

			foreach($filtered as $key)
			{
				$this->updateURL($this->dates[$key], $key);
			}
		}
		else
		{
			throw new Exception('Error updating '.$this->getName());
		}
		echo 'END '.$this->getName().": $start - $end<br>";
	}

	private function updateURL($url, $revolution)
	{
		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$satName = $satellites->getSatelliteId($this->getName());

		$fp=fopen($url,"r");

		if($fp)
		{
            $response = '';
			while($line=stream_get_line($fp,65535))
			{
				$response .= $line;
			}
			fclose($fp);

			$reg = "/<TD>\s*(?:<a\s*\.?\s*href=\"http:\/\/[a-zA-Z0-9._?\/-]+\">\s*)?([a-zA-Z0-Z_]+)\s*(?:<\/a>)?\s*<\/TD>\s*\n\s*<TD>([a-zA-Z0-9 [\],*'.+-]+)\s*<\/TD>\s*\n\s*<TD>\s*(\d+:\d+:\d+:\d+:\d+)\.\d+\s*<\/TD>\s*\n\s*<TD>\s*(\d+)\.(\d+)\s*<\/TD>\s*\n\s*<TD>\s*[a-zA-Z0-9-]+\s*<\/TD>\s*\n\s*<TD>\s*[a-zA-Z0-9-]+\s*<\/TD>\s*\n\s*<TD>\s*(\d+)\s*:\s*(\d+)\s*:\s*(\d+)\s*\.\s*(\d+)\s*<\/TD>\s*\n\s*<TD>\s*-?(\d+)\s*:\s*(\d+)\s*:\s*(\d+)\s*\.\s*(\d+)\s*<\/TD>/";
			preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

			foreach($matches as $match)
			{
				$obsId = $match[1];
				$target = $match[2];
				$start_time_a = strptime($match[3], '%Y:%j:%T');
				$start_time = ($start_time_a[tm_year]+1900).'-'.vsprintf("%02s", $start_time_a[tm_mon]+1).'-'.vsprintf("%02s", $start_time_a[tm_mday]).'T'.vsprintf("%02s", $start_time_a[tm_hour]).':'.vsprintf("%02s", $start_time_a[tm_min]).':'.vsprintf("%02s", $start_time_a[tm_sec]).'Z';
				if($match[5] > 0)
					$match[4]++;

                $duration = $match[4]*1000;
				$end_time = date('Y-m-d\TH:i:s\Z', strtotime("+$duration seconds", strtotime($start_time)));

				$ra = 15*($match[6]+($match[7]/60)+(($match[8].'.'.$match[9])/3600));
				$dec = $match[10]+($match[11]/60)+(($match[12].'.'.$match[13])/3600);

				echo "--------> $obsId<br>";
                if($target != 'CAL-ER')
    				$events->addEvent($satName, $obsId, $start_time, $end_time, $target, $revolution, $ra, $dec);
			}
		}
		else
		{
			throw new Exception('Error updating '.$this->getName());
		}
	}
}