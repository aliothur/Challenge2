<?php
class Satellite_Swift implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'Swift';
	}

	public function getActual()
	{
        if(!isset($this->actual))
        {
            $this->updateRevs();
        }

        return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
            $this->updateRevs();
		}

		return $this->future;
	}

    private function updateRevs()
    {
        $fp=fopen('http://www.swift.psu.edu/operations/obsSchedule.php',"r");
        $response = '';
        while($line=stream_get_line($fp,65535))
        {
            $response .= $line;
        }
        fclose($fp);
        //AFST current up to:&nbsp;</td><td>&nbsp;December 21st, 2009, 13:39:59 UT
        $reg='/AFST current up to:&nbsp;<\/td><td>&nbsp;(\w+) (\d{1,2})[a-zA-Z,]+ (\d{4})/';
        preg_match($reg, $response, $match);
        $month = strptime($match[1], '%B');
        if($match[2]<=9)
        	$match[2]="0".$match[2];
        $this->actual = $match[3].vsprintf("%02d", $month['tm_mon']+1).$match[2];

        //PPST current up to:&nbsp;</td><td>&nbsp;December 22nd, 2009, 00:00:00 UT
        $reg='/PPST current up to:&nbsp;<\/td><td>&nbsp;(\w+) (\d{1,2})[a-zA-Z,]+ (\d{4})/';
        preg_match($reg, $response, $match);
        $month = strptime($match[1], '%B');
        if($match[2]<=9)
        	$match[2]="0".$match[2];
        $this->future = $match[3].vsprintf("%02d", $month['tm_mon']+1).$match[2];
    }

    public function update($start, $end)
    {
        if($start<20050604)
            $start = 20050604;

        echo 'START '.$this->getName().": $start - $end<br>";

        $events = new Model_DbTable_Events();
        $satellites = new Model_DbTable_Satellites();
        $satName = $satellites->getSatelliteId($this->getName());

        $year = substr($start, 0, 4);
        $month = substr($start, 4, 2);
        $day = substr($start, 6, 2);
       
        while(($year.vsprintf("%02d", $month).vsprintf("%02d", $day)) <= $end)
        {
            $id = $year.'-'.vsprintf("%02d", $month).'-'.vsprintf("%02d", $day);
            //echo 'id: '.$id.'<br>';
            $fp=fopen('http://www.swift.psu.edu/operations/obsSchedule.php?d='.$id.'&a=1',"r");
            echo 'id: '.$id."\n"; ob_flush(); flush();
            
            if($fp)
            {
                $response = '';
                while($line=stream_get_line($fp,65535))
                {
                    $response .= $line;
                }
                fclose($fp);

                $reg = '/was not found/';
                if(!preg_match($reg, $response, $match))
                {
                    unset($matches);
                    $reg ="/<td>&nbsp;(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})&nbsp;<\/td>\s*\n\s*<td>&nbsp;(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})&nbsp;<\/td>\s*\n\s*<td>&nbsp;<a href='https:\/\/[a-zA-Z0-9._?\/=-]+'>\d+<\/a>&nbsp;<\/td>\s*\n\s*<td>&nbsp;<a href='https:\/\/[a-zA-Z0-9._?;\/=&-]+'>\d+<\/a>&nbsp;<\/td>\s*\n\s*<td style='text-align:left;'>&nbsp;([a-zA-Z0-9.+ -_]+)&nbsp;<\/td>\s*\n\s*<td>&nbsp;(\d+\.\d+)&nbsp;<\/td>\s*\n\s*<td>&nbsp;(-?\d+\.\d+)&nbsp;<\/td>/";
                    preg_match_all($reg, $response, $matches, PREG_SET_ORDER);
						

                    $i =0;
                    foreach($matches as $match)
                    {
                        echo '--------> '.$id.'-'.$i."\n";
                   		ob_flush(); flush();
                        $events->addEvent($satName,$id.'-'.$i, $match[1].'T'.$match[2].'Z', $match[3].'T'.$match[4].'Z', $match[5], $id, $match[6], $match[7]);
                        
                        $i++;
                    }
                }

                $day++;
                if($day > 31)
                {
                    $month++;
                    $day = 1;
                }
                elseif ($month > 12)
                {
                    $year++;
                    $month = 1;
                }
            }
            else
            {
                throw new Exception('Error updating '.$this->getName());
            }

            echo ($year.vsprintf("%02d", $month).vsprintf("%02d", $day)).' <= '.$end .'<br>';
        }

        echo 'END '.$this->getName().": $start - $end<br>";
    }

    //OLD < 8-Dec-2009
/*
// 	public function update($start, $end)
// 	{
// 		if($start<2005155)
// 			$start = 2005155;
//
// 		echo 'START '.$this->getName().": $start - $end<br>";
//
// 		$events = new Model_DbTable_Events();
// 		$satellites = new Model_DbTable_Satellites();
// 		$satName = $satellites->getSatelliteId($this->getName());
//
// 		$year = substr($start, 0, 4);
// 		$day = substr($start, 4, 3);
//
// 		if($day >= 365)
// 		{	//Year change
// 			$year--;
// 			$day = 360;
// 		}
//
// 		while($year.vsprintf("%03d", $day) <= $end)
// 		{
// 			$id = $year.vsprintf("%03d", $day);
// 			$fp=@fopen('http://www.swift.psu.edu/operations/PPST/'.$id.'/',"r");
//
// 			if(!$fp)
// 			{
// 				if($day >= 365)
// 				{	//Year change
// 					$year++;
// 					$day = 01;
// 				}
// 				else
// 				{	//Day with no data
// 					$day++;
// 				}
// 			}
// 			else
// 			{	//Day with data
// 				$response = '';
// 				while($line=stream_get_line($fp,65535))
// 				{
// 					$response .= $line;
// 				}
// 				fclose($fp);
//
// 				$reg = '/"(AFST_'.$id.'0000_'.($id+1).'0000_(\d{2}).html)"/';
// 				$matchNum = preg_match($reg, $response, $match);
// 				if($matchNum == 0)
// 				{
// 					$reg = '/"(PPST_'.$id.'0000_'.($id+1).'0000_(\d{2}).html)"/';
// 					$matchNum = preg_match($reg, $response, $match);
// 				}
//
// 				if($matchNum > 0)
// 				{
// 					$fp2=@fopen('http://www.swift.psu.edu/operations/PPST/'.$id.'/'.$match[1],"r");
//
// 					$regFont = '<FONT size="2"(?: color="#FF0000")?>';
//
// 					$regData = '/<TR><TD> ?'.$regFont.'(\d{4}-\d{3}-\d{2}:\d{2}:\d{2})(?:\.\d+)?(?:<\/TD>)?<TD> ?'.$regFont.'(\d{4}-\d{3}-\d{2}:\d{2}:\d{2})(?:\.\d+)?(?:<\/TD>)?<TD> ?'.$regFont.'<a href = "[a-zA-Z0-9-_+.]+.html">([a-zA-Z0-9-_+. ]+)<\/a>(?:<\/TD>)?<TD> ?'.$regFont.'(\d+\.\d+)<TD> ?'.$regFont.'(-?\d+\.\d+)(?:<\/TD>)?<TD> ?'.$regFont.'/';
// 					$responseData = '';
// 					while($line=stream_get_line($fp2, 65535))
// 					{
// 						$responseData .= $line;
// 					}
// 					fclose($fp2);
//
// 					preg_match_all($regData, $responseData, $matches, PREG_SET_ORDER);
//
// 					$i = 0;
// 					foreach($matches as $data)
// 					{
// 						echo '--------> '.$id.'-'.$i.'<br>';
//
// 						$start_time_a = strptime($data[1], '%Y-%j-%T');
// 						$end_time_a = strptime($data[2], '%Y-%j-%T');
// 						$start_time = ($start_time_a[tm_year]+1900).'-'.vsprintf("%02s", $start_time_a[tm_mon]+1).'-'.vsprintf("%02s", $start_time_a[tm_mday]).'T'.vsprintf("%02s", $start_time_a[tm_hour]).':'.vsprintf("%02s", $start_time_a[tm_min]).':'.vsprintf("%02s", $start_time_a[tm_sec]).'Z';
// 						$end_time = ($end_time_a[tm_year]+1900).'-'.vsprintf("%02s", $end_time_a[tm_mon]+1).'-'.vsprintf("%02s", $end_time_a[tm_mday]).'T'.vsprintf("%02s", $end_time_a[tm_hour]).':'.vsprintf("%02s",$end_time_a[tm_min]).':'.vsprintf("%02s",$end_time_a[tm_sec]).'Z';
//
// 						$events->addEvent($satName, $id.'-'.$i, $start_time, $end_time, $data[3], $id, $data[4], $data[5]);
// 						$i++;
// 					}
// 				}
// 				else
// 				{
// 					throw new Exception('Error updating '.$this->getName());
// 				}
//
// 				$day++;
// 			}
// 		}
// 		echo 'END '.$this->getName().": $start - $end<br>";
// 	}
*/
}