<?php
class Satellite_Fermi implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'Fermi';
	}

	public function getActual()
	{
		if(!isset($this->actual))
		{
			$this->updateRevs();
		}

		return $this->actual;
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$this->updateRevs();
		}

		return $this->future;
	}

	private function updateRevs()
	{
		$client = new Zend_Http_Client('http://fermi.gsfc.nasa.gov/ssc/observations/timeline/posting/', array(
			//'maxredirects' => 0,
			'timeout'      => 30));

		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		
		$response = $client->request('GET');
		$response=$response->getBody();
		
		preg_match_all('/<tr>[\s]+<td class="nowrap">[ \d-]+<\/td>\s+<td>(\d+)<\/td>.*<\/tr>/Umus',$response,$matches);
		$rev=max($matches[1]);
		$this->future=$rev;
		$act=ceil((time()-mktime(0,0,0,6,5,2008))/(3600*24*7));
		$this->actual=$act;
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$satName = $satellites->getSatelliteId($this->getName());

		$client = new Zend_Http_Client('http://fermi.gsfc.nasa.gov/ssc/observations/timeline/posting/', array(
			'timeout'      => 30));

		
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('/<tr>[\s]+<td class="nowrap">([ \d-]+)<\/td>\s+<td>(\d+)<\/td>\s+<td class="nowrap">([-0-9: ]+)<\/td>\s+<td class="nowrap">([-0-9: ]+)<\/td>\s+<td>([\d]+)<\/td>\s+<td class="nowrap">([^<]+)<\/td>\s+<td class="nowrap">([^<]+)<\/td>\s+<td>([^<]+)<\/td>\s+<td>([^<]+)<\/td>\s+<td>([^<]+)<\/td>\s+<td>([^<]+)<\/td>\s+<td>.*<\/td>\s+<\/tr>/Umus',$response,$matches,PREG_SET_ORDER);
		foreach($matches as $match)
		{
            
			$start=$match[3];
			$end=$match[4];
			preg_match("/^([0-9]{4})-([0-9]+)-(.*)$/",$start,$startd);
			$start=$startd[1]."-".date("m-d ",mktime(0,0,0,1,0+$startd[2],date("Y"))).$startd[3]; // change day number to normal date stamp
			preg_match("/^([0-9]{4})-([0-9]+)-(.*)$/",$end,$endd);
			$end=$endd[1]."-".date("m-d ",mktime(0,0,0,1,0+$endd[2],date("Y"))).$endd[3]; // change day number to normal date stamp
			echo "--------> $match[1]<br>";
			if(preg_match("/^Unknown$/",$match[10]))
				$match[10]="ARR";
			if(preg_match("/^none$/",$match[10]))
				$match[10]="Sky Survey";
			
			if(!preg_match("/profile week/",$match[10])&&!preg_match("/Freeze for loading/",$match[10]))
			$events->addEvent($satName, $match[1], $start,$end, $match[10], $match[2], $match[6], $match[7]);
		}

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}