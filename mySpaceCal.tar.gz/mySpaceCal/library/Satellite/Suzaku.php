<?php
class Satellite_Suzaku implements Satellite_Interface
{
    private $actual;
    private $future;
    private $dates = array();
    private $endTime;
    private $lastId;

    public function getName()
    {
        return 'Suzaku';
    }

    public function getActual()
    {
        if(!isset($this->actual))
        {
            $this->updateRevs();
        }

        return $this->actual;
    }

    public function getMaxFuture()
    {
        if(!isset($this->future))
        {
            $this->updateRevs();
        }

        return $this->future;
    }

    private function updateRevs()
    {
        $fp=fopen("http://www.astro.isas.jaxa.jp/suzaku/schedule/shortterm/","r");
        if(!$fp) {var_dump($url);die();}
        
        if($fp)
        {
            $response = '';
            while($line=stream_get_line($fp,65535))
            {
                $response .= $line;
            }
            fclose($fp);
            $reg = '/<LI><A HREF="(html\/shortterm_(\d+_\d+)(?:[a-z]|_[a-z]*(\d))?.html)">/';
            preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

            foreach($matches as $match)
            {
                $id = str_replace  ('_' ,'' ,$match[2]);
                if(!isset($this->dates[$id]) || (isset($match[3]) && ($this->dates[$id][0] < $match[3])))
                {
                    if(isset($match[3]) && $match[3] > 0)
                        $this->dates[$id][0] = $match[3];
                    else
                        $this->dates[$id][0] = 0;

                    $this->dates[$id][1] = 'http://www.astro.isas.jaxa.jp/suzaku/schedule/shortterm/'.$match[1];
                }
            }
            krsort($this->dates);
			var_dump(key($this->dates));
            $this->actual = key($this->dates);
//-----------FUTURE-------------
            $future = array();
            $fp=fopen("http://www.astro.isas.jaxa.jp/suzaku/schedule/preliminary/", "r");
            if(!$fp) {var_dump($url);die();}
            
            if($fp)
            {
                $response = '';
                while($line=stream_get_line($fp, 65535))
                {
                    $response .= $line;
                }
                fclose($fp);

                $reg = '/<LI><A HREF="(html\/shortterm_(\d+_\d+)(?:[a-z]|_[a-z]*(\d))?.html)">/';
                preg_match_all($reg, $response, $matches, PREG_SET_ORDER);
                foreach($matches as $match)
                {
                    $id = str_replace  ('_' ,'' ,$match[2]);
                    if(!isset($future[$id]) || (isset($match[3]) && ($future[$id][0] < $match[3])))
                    {
                        if(isset($match[3]) && $match[3] > 0)
                            $future[$id][0] = $match[3];
                        else
                            $future[$id][0] = 0;

                        $future[$id][1] = 'http://www.astro.isas.jaxa.jp/suzaku/schedule/preliminary/'.$match[1];

                        if($id > $this->actual)
                        {
                            $this->dates[$id] = $future[$id];
                        }

                    }
                }
                krsort($future);
                ksort($this->dates);
                var_dump(key($future));
                
                $this->future = key($future);
            }
            else
            {
                throw new Exception('Error updating '.$this->getName());
            }
        }
        else
        {
            throw new Exception('Error updating '.$this->getName());
        }
    }

    public function update($start, $end)
    {
        echo 'START '.$this->getName().": $start - $end<br>";

        global $filterStart;
        global $filterEnd;

        $filterStart = $start;
        $filterEnd = $end;

        function filterCallbackSuzaku($var)
        {
            global $filterStart;
            global $filterEnd;

            if($var >= $filterStart && $var <= $filterEnd)
                return true;
            else
                return false;
        }
        $filtered = array_filter(array_keys($this->dates), 'filterCallbackSuzaku');

        foreach($filtered as $key)
        {
            $this->updateURL($this->dates[$key][1], $key);
        }

        echo 'END '.$this->getName().": $start - $end<br>";
    }


    private function updateURL($url, $revolution)
    {
        $events = new Model_DbTable_Events();
        $satellites = new Model_DbTable_Satellites();
        $satName = $satellites->getSatelliteId($this->getName());

        $fp=fopen($url,"r");
		if(!$fp) {var_dump($url);die();}
        if($fp)
        {
            $response = '';
            while($line=stream_get_line($fp,65535))
            {
                $response .= $line;
            }
            fclose($fp);
            $reg1='/(almost final)/';
            $reg2='/(preliminary)/';
            if(preg_match($reg1, $response))
            {
                $reg = "/\s*<TD\s*ALIGN=\"left\">\s*<A\s*HREF=\"[a-zA-Z0-9.?=:&%_\/-]+\">\s*([a-zA-Z0-9_#+ .-]+)\s*<\/A>\s*<\/TD>\s*\n\s*<TD\s*ALIGN=\"left\">\s*\w+\s*<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(-?\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">\d*:?\d*:?\d*<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">[+-]?\d*:?\d*:?\d*<\/TD>\s*\n\s*<TD\s*ALIGN=\"left\">(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)<\/TD>/";
              //$reg = "/\s*<TD\s*ALIGN=\"left\">\s*<A\s*HREF=\"[a-zA-Z0-9.?=:&%_\/-]+\">\s*([a-zA-Z0-9_#+ .-]+)\s*<\/A>\s*<\/TD>\s*\n\s*<TD\s*ALIGN=\"left\">\s*\w+\s*<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(-?\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">\d+:\d+:\d+<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">[+-]?\d+:\d+:\d+<\/TD>\s*\n\s*<TD\s*ALIGN=\"left\">(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)<\/TD>/";
            	
            }
            
            elseif(preg_match($reg2, $response))
            {
                $reg = "/\s*<TD\s*ALIGN=\"left\">\s*([a-zA-Z0-9_#+ .-]+)\s*<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"right\">(-?\d+\.\d+)<\/TD>\s*\n\s*<TD\s*ALIGN=\"left\">(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)<\/TD>/";
            }
            else
            {
                throw new Exception('Error updating '.$this->getName());
            }
            preg_match_all($reg, $response, $matches, PREG_SET_ORDER);
            foreach($matches as $match)
            {
                $obsId = $match[4].$match[5].$match[6].'-'.$match[1];
                $target = $match[1];
                $start_time = $match[4].'-'.$match[5].'-'.$match[6].'T'.$match[7].':'.$match[8].':'.$match[9].'Z';
                $end_time = date('Y-m-d\TH:i:s\Z', strtotime("+30 minutes", strtotime($start_time)));

                $ra = $match[2];
                $dec = $match[3];

                if(isset($this->lastId))
                {
                    $events->updateEndTime($this->lastId, $start_time);
                    unset($this->lastId);
                }

                echo "--------> $obsId<br>";
                $this->lastId = $events->addEvent($satName, $obsId, $start_time, $end_time, $target, $revolution, $ra, $dec);
            }
        }
        else
        {
            throw new Exception('Error updating '.$this->getName());
        }
    }
}