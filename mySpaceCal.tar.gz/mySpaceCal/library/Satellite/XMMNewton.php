<?php
class Satellite_XMMNewton implements Satellite_Interface
{
	private $future;

	public function getName()
	{
		return 'XMM-Newton';
	}

	public function getActual()
	{
		$rev = strtotime('2008-05-26 03:26:12');
  		$now = strtotime('now');

  		$diff = $now-$rev;

  		$rev =  1550+($diff/172312);

		return floor($rev);
	}

	public function getMaxFuture()
	{
		if(!isset($this->future))
		{
			$salir = false;
			$next = $this->getActual()+1;
			$reg ='/Results of your query for\s+Rev = [0-9]+/';

			$i = 0;
			while(!$salir)
			{
				$fp=fopen("http://xmm2.esac.esa.int/cgi-bin/obs_search/selectobs?revn=$next","r");

				$response = '';
				while($line=stream_get_line($fp,65535))
				{
					$response .= $line;
				}
				fclose($fp);

				if(preg_match($reg, $response) > 0)
				{
					$next++;
				}
				else
				{
					$this->future = --$next;
					$salir = true;
				}
				$i++;
			}
		}

		return $this->future;
	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";

		$reg ='/<FONTFACE=\"Bookman,TimesRoman,serif\">([0-9]+)<\/FONT><\/B><\/TD><\/TR><TR><TDALIGN=\"CENTER\"><B>([a-zA-Z0-9+\-\. ]+)<\/B><\/TD><TDALIGN=\"CENTER\"><B>(\d{1,2}:\d{1,2}:\d{1,2}\.\d{1,2})<\/B><\/TD><TDCOLSPAN="2"ALIGN="CENTER"><B>([-|+]?\d{1,2}:\d{1,2}:\d{1,2}\.\d{1,2})<\/B><\/TD><TDCOLSPAN=\"2\"ALIGN=\"CENTER\"><B>\d{1,3}:\d{1,3}:\d{1,3}\.\d{1,3}<\/B><\/TD><TDROWSPAN=\"2\"WIDTH=\"250\">&nbsp;<\/TD><\/TR><TR><TDALIGN=\"CENTER\"><B>\d+sec<\/B><\/TD><TDALIGN=\"CENTER\"><B>(\d{4}-\d{1,2}-\d{1,2}@\d{1,2}:\d{1,2}:\d{1,2})<\/B><\/TD><TDCOLSPAN=\"2\"ALIGN=\"CENTER\"><B>(\d{4}-\d{1,2}-\d{1,2}@\d{1,2}:\d{1,2}:\d{1,2})<\/B><\/TD>/';

		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
		$satName = $satellites->getSatelliteId($this->getName());
		for($revolution = $start; $revolution <= $end; $revolution++)
		{

			$fp=fopen("http://xmm2.esac.esa.int/cgi-bin/obs_search/selectobs?revn=$revolution","r");

			if($fp)
			{
                $response = '';
				while($line=stream_get_line($fp,65535))
				{
					$response .= $line;
				}
				fclose($fp);

				$response = str_replace(array(' ', "\n", "\t"), '', $response);

				preg_match_all($reg, $response, $matches, PREG_SET_ORDER);

				foreach($matches as $match)
				{
					echo "--------> $match[1]<br>";
					$events->addEvent($satName, $match[1], str_replace(array('@'), 'T', $match[5]).'Z', str_replace(array('@'), 'T', $match[6]).'Z', $match[2], $revolution, $match[3], $match[4]);
				}

				unset($matches,$response);
			}
			else
			{
				throw new Exception('Error updating '.$this->getName());
			}
		}
		echo 'END '.$this->getName().": $start - $end<br>";
	}
}