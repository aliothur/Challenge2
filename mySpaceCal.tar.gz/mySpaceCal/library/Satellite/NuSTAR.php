<?php
class Satellite_NuSTAR implements Satellite_Interface
{
	private $actual;
	private $future;

	public function getName()
	{
		return 'NuSTAR';
	}

	public function getActual()
	{
		

		return 0;
	}

	public function getMaxFuture()
	{
		

		return 0;
	}

	private function updateRevs()
	{

	}

	public function update($start, $end)
	{
		echo 'START '.$this->getName().": $start - $end<br>";
		$client = new Zend_Http_Client('http://www.srl.caltech.edu/NuSTAR_Public/NuSTAROperationSite/Download.php'
		//, array(
			//'maxredirects' => 0,
			//'timeout'      => 30)
				);
		$client->setParameterGet(array(
				'file'  => 'sr-schedule.txt',
				'send_file'  => 'yes',
				
		));
		
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		$response = $client->request('GET');
		$response=$response->getBody();
		preg_match_all('/(?P<st_d>[0-9]+):(?P<st_h>[0-9]{2}:[0-9]{2}:[0-9]{2}) '.
		'(?P<end_d>[0-9]+):(?P<end_h>[0-9]{2}:[0-9]{2}:[0-9]{2}) '.
		'(?P<id>[0-9]+) (?P<name>[0-9A-Za-z_\-\+\(\)\ ]+) (?P<ra>[0-9]+\.[0-9]+) (?P<dec>[+-]?[0-9]+\.[0-9]+) /'
				
							,$response,$matches,PREG_SET_ORDER);
		
		$data=array();
		foreach($matches as $v)
			$data[]=array("name"=>$v['name'],"st_y"=>date("Y"),"st_d"=>$v['st_d'],"st_h"=>$v['st_h'],"end_y"=>date("Y"),"end_d"=>$v['end_d'],"end_h"=>$v['end_h'],"ra"=>$v['ra'],"dec"=>$v['dec'],"id"=>$v['id'],"t"=>"short");
					
		$client = new Zend_Http_Client('http://www.srl.caltech.edu/NuSTAR_Public/NuSTAROperationSite/Download.php'
				//, array(
				//'maxredirects' => 0,
				//'timeout'      => 30)
		);
		$client->setParameterGet(array(
				'file'  => 'lr-schedule.txt',
				'send_file'  => 'yes',
		
		));
		
		$client->setHeaders(array('Accept-encoding' => 'deflate'));
		$response2 = $client->request('GET');
		$response2=$response2->getBody();
		
			preg_match_all('/(?P<st_y>[0-9]{4}):(?P<st_d>[0-9]+) [0-9]{4}-[0-9]{2}-[0-9]{2} '.
		'(?P<id>[0-9]+) (?P<name>[0-9A-Za-z_\-\+\(\)\ ]+) (?P<ra>[0-9]+\.[0-9]+) (?P<dec>[+-]?[0-9]+\.[0-9]+) /'
				
							,$response2,$matches2,PREG_SET_ORDER);
		
		foreach($matches2 as $v)
			$data[]=array("name"=>$v['name'],"st_y"=>$v['st_y'],"st_d"=>$v['st_d'],"ra"=>$v['ra'],"dec"=>$v['dec'],"id"=>$v['id'],"t"=>"long");
		$max=count($data);
		for($i=0;$i<$max;$i++)
		{
			if(isset($data[$i]))
			{
			for($j=$i+1;$j<$max;$j++)
			{
			if(isset($data[$j]))
			{
			if($data[$i]['name']==$data[$j]['name']&&$data[$i]['dec']==$data[$j]['dec']&&$data[$i]['ra']==$data[$j]['ra'])
			{
				if($data[$i]['t']=="long")
				{
					unset($data[$i]);$j=$max;
				}
				else
				{
					unset($data[$j]);
				}
			}
			}
			}
			}
	
		}
		
		
		$events = new Model_DbTable_Events();
		$satellites = new Model_DbTable_Satellites();
	
		foreach($data as $v)
		{
			$satName = $satellites->getSatelliteId($this->getName());
			$revolution = 0;
		
			if($v['t']=="long")
			{
				$st_y=$v['st_y'];
				$st_d=$v['st_d'];
				$st_h="01:00:00";
				$end_y=$v['st_y'];
				$end_d=$v['st_d'];
				$end_h="23:00:00";
				
				$startTime=strtotime(date("Y-m-d",mktime(0,0,0,1,$st_d,$st_y))." ".$st_h);
				$endTime=strtotime(date("Y-m-d",mktime(0,0,0,1,$end_d,$end_y))." ".$end_h);
				$startTime = date('Y-m-d\TH:i:s\Z',$startTime);
				$endTime = date('Y-m-d\TH:i:s\Z',$endTime);
				
				
			}
			else
			{
				$st_y=$v['st_y'];
				$st_d=$v['st_d'];
				$st_h=$v['st_h'];
				$end_y=$v['end_y'];
				$end_d=$v['end_d'];
				$end_h=$v['end_h'];
				
				$startTime=strtotime(date("Y-m-d",mktime(0,0,0,1,$st_d,$st_y))." ".$st_h);
				$endTime=strtotime(date("Y-m-d",mktime(0,0,0,1,$end_d,$end_y))." ".$end_h);
				$startTime = date('Y-m-d\TH:i:s\Z',$startTime);
				$endTime = date('Y-m-d\TH:i:s\Z',$endTime);
			}
		
			$source = $v['name'];
			$ra = $v['ra'];
			$dec = $v['dec'];
			
			$obs = $v['id'];
			$id=$obs;
			
					echo "--------> $obs-$revolution<br>";
					$events->addEvent($satName, $id, $startTime, $endTime, $source, $revolution, $ra, $dec);
				

		

			}
		

		echo 'END '.$this->getName().": $start - $end<br>";
	}
}