<?php
class Satellite_Abstract_XML implements Satellite_Interface
{
	$_url='';

	abstract protected function getName();
	abstract protected function getActual();
	abstract protected function getMaxFuture();

	public function update($start, $end)
	{
		$reader = new XMLReader();
		$reader->open($_url."?start=$start&end=$end");

		while ($reader->read()) {
			switch ($reader->nodeType) {
				case (XMLREADER_ELEMENT):
				print $reader->localName ." ";
				if ($reader->namespaceURI) {
					print "NS: $reader->namespaceURI ";
				}
				break;
			}
		}
	}
}