<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
    	$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/application.ini', APPLICATION_ENV);

        $s = new Model_DbTable_Satellites();
        $select = $s->select()->where(Model_DbTable_Satellites::STATUS.'=1');
        $this->view->sats = $s->fetchAll($select);

        $request = $this->getRequest();
        $add_filters_c=$request->getCookie('add_filters');
        
        if(!$add_filters_c)
        {
        	$saa_cold=0;
        	$dummy=0;
        }
        if(!preg_match("/^[a-zA-Z0-9\-,_]*$/",$add_filters_c))
        	$add_filters_c="";
        
        $add_filters = explode(',',substr($add_filters_c, 0, -1));
        $this->view->saa_cold=(in_array("saa_cold",$add_filters)?1:0);
        $this->view->dummy=(in_array("dummy",$add_filters)?1:0);
             
        $this->view->satsCo = array();
 
        $cookie = $request->getCookie('sats');
        if(!preg_match("/^[a-zA-Z0-9\-,]*$/",$cookie))
        	$cookie="";
        
        if($cookie != null)
        {//Cookie exists
            $l = explode(',',substr($cookie, 0, -1));

            foreach($l as $sat)
            {
                $this->view->satsCo[$sat] = true;
            }
        }
        else
        {//Cookie no exists
            $response = $this->getResponse();
            setcookie('sats', 'Integral,XMM-Newton,', time()+31536000, $config->cookies->path);
            $this->view->satsCo['Integral'] = true;
            $this->view->satsCo['XMM-Newton'] = true;
        }

        $cookie2 = $request->getCookie('search');
        if($cookie2)
        {
            $this->view->search = $cookie2;
        }
    }

    public function ajaxAction()
    {
        if ($this->_helper->hasHelper('Layout')) {
                	$this->_helper->layout->disableLayout();
        }

        $request = $this->getRequest();
        if($request->isGet())
        {
            switch($request->getQuery('func'))
            {
                case 'data':
                    $validator = new Zend_Validate_Digits();
                    $startValue = $request->getQuery('start');
                    $endValue = $request->getQuery('end');
                    if($validator->isValid($startValue) && $validator->isValid($endValue))
                    {
                        $start = date('Y-m-d H:i:s', $startValue);
                        $end = date('Y-m-d H:i:s', $endValue);

                        $cookie = $request->getCookie('sats');
                        if(!preg_match("/^[a-zA-Z0-9\-,]*$/",$cookie))
                        	$cookie="";
                      
                        $sats = explode(',',substr($cookie, 0, -1));
                        $add_filters_c = $request->getCookie('add_filters');
                        if(!$add_filters_c)
                        	$saa_cold=$dummy=0;
                        if(!preg_match("/^[a-zA-Z0-9\-,_]*$/",$add_filters_c))
                        	$add_filters_c="";
                        
                        $add_filters = explode(',',substr($add_filters_c, 0, -1));
                        $saa_cold=(in_array("saa_cold",$add_filters)?1:0);
        				$dummy=(in_array("dummy",$add_filters)?1:0);
                        if(Zend_Auth::getInstance()->hasIdentity())
                        {
                            $u = new Model_DbTable_Users();
                            $u->updateUserSatellites(Zend_Auth::getInstance()->getStorage()->read()->id, $cookie,$saa_cold,$dummy);
                        }
                        
                        $h_s = new Model_DbTable_Satellites();
                        $h_select = $h_s->select()->where(Model_DbTable_Satellites::STATUS.'=1');                        
                        $h_satellites = $h_s->fetchAll();
                        $satByName=array();
                        $satClassNameById=array();
                        foreach($h_satellites as $h_satellite)
                        	if($h_satellite->active)
                        		{
                        		$satByName[$h_satellite->name]=$h_satellite->id;
                        		$satClassNameById[$h_satellite->id]=$h_satellite->classname;
                        		}
                        
                        unset($h_s,$h_select,$h_satellites);
                        
                        
                        $db = Zend_Db_Table::getDefaultAdapter();
                        $select = $db->select()->from(array('e' => 'events'), array('id', 'start_time', 'end_time', 'target','id_satellite'))
                                    //->joinInner(array('s' => 'satellites'), 'e.id_satellite = s.id', 'classname')
                                //    ->where(Model_DbTable_Satellites::STATUS.'=1') 
                                    ->where('end_time >= ?', $start)
                                    ->where('start_time < ?', $end);
                        $sats_ids=array();
                        //die(var_dump($sats));
                        foreach($sats as $key=>$sat)
                        	if(empty($sat)) unset($sats[$key]);
                        if(count($sats) > 0)
                        	{
                     		foreach($sats as $sat)
                     			if(isset($satByName[$sat]))
                     				$sats_ids[]=$satByName[$sat];
                     		//$sats_ids=array((int)($request->getQuery('sat')));
                     		
           					if(count($sats_ids)==0)
           							$select->where("1=2");
           					else
                            	$select->where("id_satellite IN(".implode(",",$sats_ids).")");
                            
                        	}
                        else
                        	{
                        	$select->where("1=2");
                        	}
              
                        if(!$saa_cold)
                        		$select->where("saa_cold = 0 ");
                        if(!$dummy)
                        		$select->where("dummy = 0");
                        
                        
                        $select->order(array('start_time ASC'));

                        $cookie2 = $request->getCookie('search');
                        if(!preg_match("/^[a-zA-Z0-9 \-%*_]*$/",$cookie2))
                        	{
                        	$cookie2=null;
                        	//$select->where("1=2");
                        	}
                        if($cookie2)
                        {
							if(!preg_match("/\%$/",$cookie2))
								$cookie2.="%";	
							$cookie2=trim(str_replace("*","%",$cookie2));
                        	$select->where('target LIKE ?', $cookie2);
                        }
                        
                        $events = $db->fetchAll($select);

                        $this->view->data = array();
                        foreach($events as $event)
                        {
                            $this->view->data[] = array(
                                'id' => $event['id'],
                                'start' => $event['start_time'],
                            	'end'=> $event['end_time'],   
                            // 'end' => (strtotime($event['end_time'])-strtotime($event['start_time'])<20*60?strtotime($event['start_time']."+10 minutes"):$event['end_time']),
                                'title' => $event['target'],
                               	'className' => $satClassNameById[$event['id_satellite']] 
                            );
                        }
                        
                        $this->view->func = 'data';
                    }
                    break;
                case 'data1': 
                	sleep(5);break;
                case 'info':
                    $validator = new Zend_Validate_Int();
                    $id = $request->getQuery('id');
                    if($validator->isValid($id))
                    {
                        $e = new Model_DbTable_Events();
                        $s = new Model_DbTable_Satellites();

                        $this->view->event = $e->getEvent($id);
                        $this->view->satellite = $s->getSatellite($this->view->event->id_satellite);
                        $this->view->func = 'info';
                    }
                    break;
            }
        }
    }
	public function exportAction()
	{
		
		function array_to_csv($array, $header_row = true, $col_sep = ",", $row_sep = "\n", $qut = '"')
		{
			/**
			 * Generatting CSV formatted string from an array.
			 * By Sergey Gurevich.
			 */
			if (!is_array($array) or !is_array($array[0])) return false;
			$output="";
			//Header row.
			if ($header_row)
			{
				foreach ($array[0] as $key => $val)
				{
					//Escaping quotes.
					$key = str_replace($qut, "$qut$qut", $key);
					$output .= "$col_sep$qut$key$qut";
				}
				$output = substr($output, 1)."\n";
			}
			//Data rows.
			foreach ($array as $key => $val)
			{
				$tmp = '';
				foreach ($val as $cell_key => $cell_val)
				{
					//Escaping quotes.
					$cell_val = str_replace($qut, "$qut$qut", $cell_val);
					$tmp .= "$col_sep$qut$cell_val$qut";
				}
				$output .= substr($tmp, 1).$row_sep;
			}
		
			return $output;
		}
		
		
		
		
		$request = $this->getRequest();
		
		$target = $request->getCookie('search');
		if(!preg_match("/^[a-zA-Z0-9 \-%*_]*$/",$target))
		{
			$target=null;
			//$select->where("1=2");
		}
		if($target)
		{
			
			$target=trim(str_replace("%","*",$target));
			$this->view->target=$target;
		
			//$select->where('target LIKE ?', $target);
		}
		
		$export = $request->getParam('sat');
		
		$this->view->satsCo = array();
	
		$cookie = $request->getCookie('sats');
		if(!preg_match("/^[a-zA-Z0-9\-,]*$/",$cookie))
			$cookie="";
		
		if($cookie != null)
		{//Cookie exists
		$l = explode(',',substr($cookie, 0, -1));
		
		foreach($l as $sat)
		{
			$this->view->satsCo[$sat] = true;
		}
		}
		else
		{//Cookie no exists
		$response = $this->getResponse();
		$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/application.ini', APPLICATION_ENV);
			
		setcookie('sats', 'Integral,XMM-Newton,', time()+31536000, $config->cookies->path);
		$this->view->satsCo['Integral'] = true;
		$this->view->satsCo['XMM-Newton'] = true;
		}
		
		$add_filters_c=$request->getCookie('add_filters');
		
		if(!$add_filters_c)
		{
			$saa_cold=0;
			$dummy=0;
		}
		if(!preg_match("/^[a-zA-Z0-9\-,_]*$/",$add_filters_c))
			$add_filters_c="";
		
		$add_filters = explode(',',substr($add_filters_c, 0, -1));
		$this->view->saa_cold=(in_array("saa_cold",$add_filters)?1:0);
		$this->view->dummy=(in_array("dummy",$add_filters)?1:0);
		
			$s = new Model_DbTable_Satellites();
			$this->view->satellites = $s->fetchAll("active=1");
			$active_sats=array();
			$satNameById=array();
			foreach($this->view->satellites as $v)
			{
				$active_sats[]=$v->id;
				$satNameById[$v->id]=$v->getName();
			}
		try
		{
			$format=$request->getParam('format');
			if(!(is_null($format))&&is_null($export))	
				throw new Exception("You have to choose at least one satellite.");	
				
			if($export)
			{
				$this->view->only_data = true;
				
				
				$sat_ids=$export;
				foreach($sat_ids as $k=>$v)
				{
					$v=(int)$v;
					if($v<=0)
					unset($sat_ids[$k]);
					
				}
				
				foreach($sat_ids as $k=>$v)
				{
					if(!in_array($v,$active_sats))
						unset($sat_ids[$k]);
				}
				if(count($sat_ids)==0)
					throw new Exception("No satellites available");
				$start=strtotime($request->getParam('start_date'));
				$end=strtotime($request->getParam('end_date'))+24*3600-1;
				if(!$start||!$end||$start>$end)
					throw new Exception("Wrong date");	
				if(!$request->getParam('dummy'))
					$dummy='dummy = 0';
				else 
					$dummy=null;
				if(!$request->getParam('saa_cold'))
					$saa_cold='saa_cold = 0';
				else
					$saa_cold=null;
				
				$db = Zend_Db_Table::getDefaultAdapter();
				$select = $db->select()->from(array('e' => 'events'), array('id_satellite','target', 'start_time', 'end_time','ra','decl','revolution'))
				->where('start_time <= ?', date('Y-m-d H:i:s',$end))
				->where('end_time >= ?',date('Y-m-d H:i:s',$start))
				->where('id_satellite IN('.implode(",",$sat_ids).')');
				//$events = $db->fetchAll($select);
				if($dummy)
					$select->where($dummy);
				if($saa_cold)
					$select->where($saa_cold);
				$target = $request->getParam('target');
				if(!preg_match("/^[a-zA-Z0-9 \-%*_]*$/",$target))
				{
					$target=null;
					//$select->where("1=2");
				}
				if($target)
				{
					$this->view->target=$target;
					if(!preg_match("/\%$/",$target))
						$target.="%";
					$target=trim(str_replace("*","%",$target));
					$this->view->target=$target;
						
					$select->where('target LIKE ?', $target);
				}
				
				
				
				$select=$db->query($select);
				
				 	
				
				if ($this->_helper->hasHelper('Layout'))
				{
					$this->_helper->layout->disableLayout();
				}	

				header("Content-type: text/csv");
				header("Content-Disposition: attachment; filename=obs.csv");
				header("Pragma: no-cache");
				header("Expires: 0");
				
				switch($request->getParam('format'))
				{
					
					case 1:
							
							while($row=$select->fetch())
							{
								echo array_to_csv(array(array($row['id_satellite'],$satNameById[$row['id_satellite']],$row['target'],$row['start_time'],$row['end_time'],$row['ra'],$row['decl'],$row['revolution'])),false);
								//ob_flush();
							}
							break;
					default:	
							while($row=$select->fetch())
							{
								echo array_to_csv(array(array($row['id_satellite'],$satNameById[$row['id_satellite']],$row['target'],$row['start_time'],$row['end_time'],$row['ra'],$row['decl'],$row['revolution'])),false);
								//ob_flush();
							}
							
							break;
				}
				
			}
		}
		catch(Exception $e)
		{
			$this->view->error=$e->getMessage();			
			
		}
			
	}
    public function icalAction()
    {
    	
    	/*
    	 * Export stuff
    	 */
    	$request = $this->getRequest();
    	
    	$target = $request->getCookie('search');
    	if(!preg_match("/^[a-zA-Z0-9 \-%*_]*$/",$target))
    	{
    		$target=null;
    		//$select->where("1=2");
    	}
    	if($target)
    	{
    			
    		$target=trim(str_replace("%","*",$target));
    		$this->view->target=$target;
    	
    		//$select->where('target LIKE ?', $target);
    	}
    	
    	$export = $request->getParam('sat');
    	
    	$this->view->satsCo = array();
    	
    	$cookie = $request->getCookie('sats');
    	if(!preg_match("/^[a-zA-Z0-9\-,]*$/",$cookie))
    		$cookie="";
    	
    	if($cookie != null)
    	{//Cookie exists
    	$l = explode(',',substr($cookie, 0, -1));
    	
    	foreach($l as $sat)
    	{
    		$this->view->satsCo[$sat] = true;
    	}
    	}
    	else
    	{//Cookie no exists
    	$response = $this->getResponse();
    	$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/application.ini', APPLICATION_ENV);
    		
    	setcookie('sats', 'Integral,XMM-Newton,', time()+31536000, $config->cookies->path);
    	$this->view->satsCo['Integral'] = true;
    	$this->view->satsCo['XMM-Newton'] = true;
    	}
    	
    	$add_filters_c=$request->getCookie('add_filters');
    	
    	if(!$add_filters_c)
    	{
    		$saa_cold=0;
    		$dummy=0;
    	}
    	if(!preg_match("/^[a-zA-Z0-9\-,_]*$/",$add_filters_c))
    		$add_filters_c="";
    	
    	$add_filters = explode(',',substr($add_filters_c, 0, -1));
    	$this->view->saa_cold=(in_array("saa_cold",$add_filters)?1:0);
    	$this->view->dummy=(in_array("dummy",$add_filters)?1:0);
        Zend_Loader::loadFile('iCalcreator.php');

        $validator = new Zend_Validate_Int();
        $request = $this->getRequest();
        $id = $request->getParam('id', -1);
        if($id == -1)
        {
            $s = new Model_DbTable_Satellites();
            $this->view->satellites = $s->fetchAll('active=1');

        }
        elseif($validator->isValid($id))
        {
            if ($this->_helper->hasHelper('Layout')) {
                $this->_helper->layout->disableLayout();
            }

            $db = Zend_Db_Table::getDefaultAdapter();
            $select = $db->select()->from(array('e' => 'events'), array('id', 'start_time', 'end_time', 'target'))
                        ->joinInner(array('s' => 'satellites'), 'e.id_satellite = s.id', 'name')
                        ->where('start_time >= ?', date('Y-m-').'01T00:00:00Z')
                        ->where('s.id = '.$id)
                        ->where(Model_DbTable_Satellites::STATUS.' = 1');
            $events = $db->fetchAll($select);

            $v = new vcalendar();                          // initiate new CALENDAR
            foreach($events as $event)
            {
                $e = new vevent();                             // initiate a new EVENT
                $e->setProperty( 'CATEGORIES'
                    , 'mySpaceCal' );                   // catagorize

                $e->setProperty( 'DTSTART'
                    , $event['start_time']);
                $e->setProperty( 'DTEND'
                    , $event['end_time']);

                $e->setProperty( 'DESCRIPTION'
                    , 'Target: '.$event['target']);    // describe the event
                $e->setProperty( 'SUMMARY'
                    , 'Satellite: '.$event['name']);                     // locate the event

                $v->addComponent( $e );                        // add component to calendar

            }

            $this->view->calendar = $v->createCalendar();                   // generate and get output in string, for testing?
        }
    }

    public function autocompleteAction()
    {
        // The data sent via the ajax call is inside $_GET['q']
        $filter = $_GET['q'];
        $h_s = new Model_DbTable_Satellites();
        $h_select = $h_s->select()->where(Model_DbTable_Satellites::STATUS.'=1');
        $h_satellites = $h_s->fetchAll();
        $satByName=array();
        $satClassNameById=array();
        foreach($h_satellites as $h_satellite)
        	if($h_satellite->active)
        	{
        		$satByName[$h_satellite->name]=$h_satellite->id;
        		$satClassNameById[$h_satellite->id]=$h_satellite->classname;
        	}
        
        	unset($h_s,$h_select,$h_satellites);
        $db = Zend_Db_Table::getDefaultAdapter();
        $select = $db->select()->from(array('e' => 'events'), array('target','id_satellite'))
                    //->joinInner(array('s' => 'satellites'), 'e.id_satellite = s.id', '')
                   // ->where(Model_DbTable_Satellites::STATUS.' = 1')
        			// no need to inner join (satClassNameById)
                    ->where('target LIKE ?', '%'.$filter.'%')
                    ->distinct();
        $events = $db->fetchAll($select);

        $data=array();
        foreach($events as $event)
            if(isset($satClassNameById[$event['id_satellite']]))
        		$data[] = $event['target']."\n";

        $this->_helper->autoComplete($data);
    }

    public function aboutAction()
    {
        // action body
    }

    public function helpAction()
    {
        // action body
    }
}
