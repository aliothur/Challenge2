<?php

class SatelliteController extends Zend_Controller_Action
{
    public function init()
    {
    }

    public function indexAction()
    {
        $satellites = new Model_DbTable_Satellites();

        //Load all classes of the Satellites directory
        $sats = array();
        if ($handle = opendir(APPLICATION_PATH . '/../library/Satellite')) {
        	while (false !== ($file = readdir($handle))) {
        		if($file != 'Interface.php' && $file != 'AbstractXML.php' && $file[0] != '.')
        		{
        			$name = explode('.', $file);
        			$sats[] = $name[0];
        		}
        	}

        	closedir($handle);
        }

        foreach($sats as $satFileName)
        {
        	$satName = 'Satellite_'.$satFileName;
        	$satC = new $satName();

        	if($satC instanceOf Satellite_Interface)
        	{
        		try
        		{
        			$satD = $satellites->getSatelliteByName($satC->getName());
        		}
        		catch (Exception $e)
        		{
        			//Add the new satellite to the DB if no exists
        			$satellites->addSatellite(0, $satC->getName(), $satName, null, 0, '#3366CC');
					$this->updateColors();
        		}
        	}
        }

        $this->view->satellites = $satellites->fetchAll();
    }

    public function updateAction()
    {
         set_time_limit(0);

         if ($this->_helper->hasHelper('Layout')) {
             $this->_helper->layout->disableLayout();
         }
         $this->_helper->viewRenderer->setNoRender(true);

         $db = Zend_Db_Table::getDefaultAdapter();
         $satellites = new Model_DbTable_Satellites();
         $events = new Model_DbTable_Events();

         $select = $satellites->select()->where(Model_DbTable_Satellites::STATUS.' = 1');
         $sats = $satellites->fetchAll($select);

        $ini = 0;
        $end = 0;
        
        

         foreach($sats as $sat)
         {
             try
             {
             	echo $sat->getName();
                 $db->beginTransaction();

                 if($sat->getMaxFuture() < $sat->getActual())
                 {
                     throw new Exception($sat->getMaxFuture().' < '.$sat->getActual());
                 }

                 if($sat->last_updated < $sat->getActual())
                 {
                     if(($sat->last_updated-5) < 0)
                         $ini = 0;
                     else
                         $ini = $sat->last_updated-5;

                     $end = $sat->getMaxFuture();

                     $events->deleteEventsRevolutions($sat->id, $ini, $end);
                     $sat->update($ini, $sat->getMaxFuture());
                     $satellites->updateSatelliteData($sat->id, array(Model_DbTable_Satellites::LAST_REV => $sat->getActual()));
                 }
                 else
                 {
                     if(($sat->getActual()-5) < 0)
                         $ini = 0;
                     else
                         $ini = $sat->getActual()-5;

                     $end = $sat->getMaxFuture();

                     $events->deleteEventsRevolutions($sat->id, $ini, $end);
                     $sat->update($ini, $sat->getMaxFuture());
                 }

                 $db->commit();
             }
             catch (Exception $e)
             {
                     $db->rollBack();
                     echo '\''.$sat->getName().'\' not updated'.$ini.' - '.$end.': '.$e->getMessage().'.<br>';
                     $this->sendErrorMail($sat->getName(), '\''.$sat->getName().'\' not updated: '.$e->getMessage().'.');
             }
     //          echo $sat->getName().'->'.$sat->getActual().'-'.$sat->getMaxFuture().'<br>';
         }
    }

    private function sendErrorMail($satName, $errorMsg)
    {
        $mail = new Zend_Mail();
        $mail->setBodyText($errorMsg);
        $mail->setFrom('jkaluzny@sciops.esa.int', 'mySpaceCal Team');
        $mail->addTo('jkaluzny@sciops.esa.int', 'mySpaceCal Admin');
        $mail->setSubject('[mySpaceCal] Error updating '.$satName.'.');
        $mail->send();
    }

	private function updateColors()
	{
		$satellites = new Model_DbTable_Satellites();
		$sats = $satellites->fetchAll();

		$handle = fopen(APPLICATION_PATH.'/../public/css/sats.css', 'w');

		foreach($sats as $sat)
		{
			$c = Model_DbTable_Satellites::CLASS_NAME;
			$c2 = Model_DbTable_Satellites::COLOR;
			$classname = $sat->$c;
			$color =  $sat->$c2;

			$css = ".$classname,
				.fc-agenda .$classname .fc-event-time,
				.$classname a {
					background-color: $color; /* background color */
					border-color: $color;     /* border color (often same as background-color) */
				}\n";

			fwrite($handle, $css);
		}
		fclose($handle);
	}

    public function ajaxAction()
    {
	    if ($this->_helper->hasHelper('Layout')) {
		    $this->_helper->layout->disableLayout();
	    }
	    //$this->_helper->viewRenderer->setNoRender(true);

	    $request = $this->getRequest();
	    if($request->isPost())
	    {
		    $satellites = new Model_DbTable_Satellites();
		    $id = $request->getPost('id');
		    switch($request->getPost('func'))
		    {
			    case 'color':
				    $color = $request->getPost('color');
				    $satellites->updateColor($id, $color);

				    $this->updateColors();
				    break;
			    case 'state':
				    $state = $request->getPost('state');

				    $satellites->updateState($id, $state);

				    $this->view->state = $state;
				    $this->view->id = $id;
				    break;
			    case 'delete':
				    $satellites->deleteSatellite($id);
				    break;
                case 'new':
                    $name = $request->getPost('name');
                    $url = $request->getPost('url');

                    if($name && $url)
                    {
                        $this->view->id = $satellites->addSatellite(0, $name, null, $url, 0, '#3366CC');
                        $this->updateColors();
                    }

                    break;
		    }
	    }
    }
}
