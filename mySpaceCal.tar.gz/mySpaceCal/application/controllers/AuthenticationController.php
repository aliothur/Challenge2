<?php

class AuthenticationController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $this->_redirect('authentication/login');
    }

    public function loginAction()
    {
    	$config = new Zend_Config_Ini(APPLICATION_PATH . '/configs/application.ini', APPLICATION_ENV);
    	 
	    if(Zend_Auth::getInstance()->hasIdentity())
	    {
		    $this->_redirect('/');
	    }

	    $request = $this->getRequest();
	    $form = new Form_LoginForm();
	    if($request->isPost())
	    {
		    if($form->isValid($this->_request->getPost()))
		    {
			    $authAdapter = $this->getAuthAdapter();

			    $username = $form->getValue('username');
			    $password = $form->getValue('password');

			    $authAdapter->setIdentity($username)
					    ->setCredential($password);

			    $auth = Zend_Auth::getInstance();
			    $result = $auth->authenticate($authAdapter);

			    if($result->isValid())
			    {
				    $identity = $authAdapter->getResultRowObject();

				    $authStorage = $auth->getStorage();
				    $authStorage->write($identity);
				    
				    setcookie('sats', $authStorage->read()->sats, time()+31536000, $config->cookies->path);
				    $add_filters=array();
				    if($authStorage->read()->saa_cold)
				    	$add_filters[]="saa_cold";
				    if($authStorage->read()->dummy)
				    	$add_filters[]="dummy";
				    if(count($add_filters)>0)
				    	setcookie('add_filters', implode(",",$add_filters).",", time()+31536000, $config->cookies->path);
				    
				    $cookie = $request->getCookie('url');
				    if($cookie == null)
				    {
					    $this->_redirect('/');
				    }
				    else
				    {
					    setcookie('url', '', time() - 3600,$config->cookies->path);
					    $this->_redirect($cookie);
				    }
			    }
			    else
			    {
				    $this->view->errorMessage = 'Wrong User name or password.';
			    }
		    }
	    }

	    $this->view->form = $form;
    }

    public function logoutAction()
    {
        Zend_Auth::getInstance()->clearIdentity();
        	setcookie('url', '', time() - 3600, $config->cookies->path);
        	$this->_redirect('/');
    }

    private function getAuthAdapter()
    {
        $authAdapter = new Zend_Auth_Adapter_DbTable(Zend_Db_Table::getDefaultAdapter());
        	$authAdapter->setTableName('users')
        		    ->setIdentityColumn('username')
        		    ->setCredentialColumn('password')
        		    ->setCredentialTreatment('MD5(?)');

        	return $authAdapter;
    }

    public function registerAction()
    {
	    if(Zend_Auth::getInstance()->hasIdentity())
	    {
		    $this->_redirect('/');
	    }

	    $request = $this->getRequest();
	    $form = new Form_NewUserForm();
	    if($request->isPost())
	    {
		    if($form->isValid($this->_request->getPost()))
		    {
			    $username = $form->getValue('username');
			    $password = $form->getValue('password');

			    //***************************
			    //Check that the username is not present in the database
                $validator = new Zend_Validate_Db_NoRecordExists('users', 'username');

			    if ($validator->isValid($username))
			    {
				    $request = $this->getRequest();
				    $cookie = $request->getCookie('sats');

				    $u = new Model_DbTable_Users();
				    $u->addUser($username, md5($password), 'user', $cookie);

				    $authAdapter = $this->getAuthAdapter();

				    $authAdapter->setIdentity($username)
						    ->setCredential($password);

				    $auth = Zend_Auth::getInstance();
				    $result = $auth->authenticate($authAdapter);

				    if($result->isValid())
				    {
					    $identity = $authAdapter->getResultRowObject();

					    $authStorage = $auth->getStorage();
					    $authStorage->write($identity);

					    $this->view->message = 'You are now registered and loged in!';
					    $this->view->headMeta()->appendHttpEquiv('Refresh', '3;URL=/');
				    }
				    else
				    {
					    $this->view->message = 'Wrong User name or password.';
				    }
			    }
			    else
			    {
				    // username is invalid; print the reason
				    $this->view->message = $validator->getMessages();
				    $this->view->form = $form;
			    }
			    //***************************
		    }
		    else
		    {
			    $this->view->message = 'Username or password not valid.';
			    $this->view->form = $form;
		    }
	    }
	    else
	    {
		    $this->view->form = $form;
	    }
    }
}