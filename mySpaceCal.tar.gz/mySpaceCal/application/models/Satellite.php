<?php
class Model_Satellite extends Zend_Db_Table_Row_Abstract implements  Satellite_Interface
{
    public $c;
    private $actual;
    private $future;

	function __get($key)
	{
		if(method_exists($this, $key))
		{
			return $this->$key();
		}

		return parent::__get($key);
	}

    public function __construct($config)
    {
        parent::__construct($config);
        if($this->classname)
        {
            $satClass = $this->classname;
            $this->c = new $satClass();
        }
    }

    public function getName()
    {
            return $this->name;
    }

    public function getActual()
    {
        if($this->c)
        {
            return $this->c->getActual();
        }
        else
        {
            if(!isset($this->actual))
            {
                $this->updateRevs();
            }

            return $this->actual;
        }
    }

    public function getMaxFuture()
    {
        if($this->c)
        {
            return $this->c->getMaxFuture();
        }
        else
        {
            if(!isset($this->future))
            {
                $this->updateRevs();
            }

            return $this->future;
        }
    }

    private function updateRevs()
    {
        $reader = new XMLReader();

//         if(!@$reader->open('http://scil17:8080/testIndex.xml'))
//             throw new Exception('Error opening '.$this->xml_url.' on '.$this->getName());

        if(!@$reader->open($this->xml_url))
            throw new Exception('Error opening '.$this->xml_url.' on '.$this->getName());

        $reader->setSchema(APPLICATION_PATH . '/../public/satellites.xsd');

        while (@$reader->read())
        {
            if ($reader->nodeType == XMLREADER::ELEMENT)
                $parent = $reader->localName;
            elseif($reader->nodeType == XMLREADER::TEXT)
            {
                if($reader->isValid())
                {
                    if($parent == 'actual')
                        $this->actual = $reader->value;
                    elseif($parent == 'maxFuture')
                        $this->future = $reader->value;
                }
                else
                    throw new Exception('Validation error on '.$this->getName());
            }
        }
    }

    public function update($start, $end)
    {
        if($this->c)
        {
            $this->c->update($start, $end);
        }
        else
        {
            echo 'START '.$this->getName().": $start - $end<br>";
            $db = Zend_Db_Table::getDefaultAdapter();
            $events = new Model_DbTable_Events();
            $reader = new XMLReader();

//             if(!@$reader->open('http://scil17:8080/test.xml'))
//                 throw new Exception('Error opening '.$this->xml_url.' on '.$this->getName());

            if(!@$reader->open($this->xml_url.'?start='.$start.'&end='.$end))
                throw new Exception('Error opening '.$this->xml_url.' on '.$this->getName());

            $reader->setSchema(APPLICATION_PATH . '/../public/events.xsd');

            while (@$reader->read())
            {
                if ($reader->nodeType == XMLREADER::ELEMENT)
                {
                    if($reader->localName == 'event')
                        $e = $events->createRow();
                    else
                       $parent = $reader->localName;
                }
                elseif($reader->nodeType == XMLREADER::TEXT)
                {
                    if($reader->isValid())
                    {
                        if($parent == 'observationId')
                            $e->id_observation = $reader->value;
                        elseif($parent == 'startTime')
                            $e->start_time = $reader->value;
                        elseif($parent == 'endTime')
                            $e->end_time = $reader->value;
                        elseif($parent == 'target')
                            $e->target = $reader->value;
                        elseif($parent == 'revolution')
                            $e->revolution = $reader->value;
                        elseif($parent == 'ra')
                            $e->ra = $reader->value;
                        elseif($parent == 'dec')
                            $e->dec = $reader->value;
                    }
                    else
                        throw new Exception('Validation error on '.$this->getName());
                }
                elseif($reader->nodeType == XMLREADER::END_ELEMENT)
                {
                    if($reader->localName == 'event')
                    {
                        if($reader->isValid())
                        {
                            $e->id_satellite = $this->id;
                            echo "--------> $e->id_observation<br>";
                            $e->save();
                        }
                        else
                            throw new Exception('Validation error on '.$this->getName());
                    }
                }
            }
            echo 'END '.$this->getName().": $start - $end<br>";
        }
    }
}