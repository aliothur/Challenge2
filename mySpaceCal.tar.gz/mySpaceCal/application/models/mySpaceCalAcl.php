<?php
class Model_mySpaceCalAcl extends Zend_Acl
{
	public function __construct()
	{
		$this->add(new Zend_Acl_Resource('index'));

		$this->add(new Zend_Acl_Resource('satellite'));

		$this->add(new Zend_Acl_Resource('authentication'));
		$this->add(new Zend_Acl_Resource('login'), 'authentication');
		$this->add(new Zend_Acl_Resource('error'));
        $this->add(new Zend_Acl_Resource('help'));

		$this->addRole(new Zend_Acl_Role('guest'));
		$this->addRole(new Zend_Acl_Role('user'), 'guest');
		$this->addRole(new Zend_Acl_Role('admin'), 'user');

		//Guest
		$this->allow('guest', 'index');
        $this->allow('guest', 'help');
		$this->allow('guest', 'error');
		$this->allow('guest', 'authentication');
		$this->allow('guest', 'satellite', 'update');

		//User
		$this->deny('user', 'login');

		//Admin
		$this->allow('admin', 'satellite');
	}
}