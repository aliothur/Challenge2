<?php
class Model_DbTable_Users extends Zend_Db_Table_Abstract
{
	protected $_name = 'users';
	protected $_rowClass = 'Model_User';

	public function getUser($id)
	{
		$id = (int)$id;
		$row = $this->fetchRow('id = ' . $id);
		if(!$row) {
			throw new Exception("User not found");
		}

		return $row;
	}

	public function getUserByUsername($username)
	{
		$id = (int)$id;
		$row = $this->fetchRow('username = \'' . $username.'\'');

		return $row;
	}

	public function addUser($username, $password, $role, $sats)
	{
		$data = array(
			'username' => $username,
			'password' => $password,
			'role' => $role,
			'sats' => $sats,
		);
		$this->insert($data);
	}

	public function updateUser($id, $username, $password, $role, $sats)
	{
		$data = array(
			'username' => $username,
			'password' => $password,
			'role' => $role,
			'sats' => $sats,
		);
		$this->update($data, 'id = ' .(int)$id);
	}

	public function deleteUser($id)
	{
		$this->delete('id =' . (int)$id);
	}

	public function updateUserSatellites($id, $sats,$saa_cold=null,$dummy=null)
	{
		$data = array(
			'sats' => $sats,
		);
	/*	if(!is_null($saa_cold))
			$data['saa_cold']=(int)$saa_cold;
		if(!is_null($dummy))
			$data['dummy']=(int)$dummy;	
		*/
		$this->update($data, 'id = ' .(int)$id);
		
		
	}
}