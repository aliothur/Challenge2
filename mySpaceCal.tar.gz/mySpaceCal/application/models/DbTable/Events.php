<?php
class Model_DbTable_Events extends Zend_Db_Table_Abstract
{
	protected $_name = 'events';
	protected $_rowClass = 'Model_Event';
	protected $_referenceMap = array(
		'Satellite' => array(
			'columns'       => array('id_satellite'),
			'refTableClass' => 'Model_DbTable_Satellites',
			'refColumns'    => array('id')
		)
	);

	public function getEvent($id)
	{
		$id = (int)$id;
		$row = $this->fetchRow('id = ' . $id);
		if(!$row) {
			throw new Exception("Event not found");
		}
		return $row;
	}

	public function addEvent($id_satellite,$id_observation, $start_time, $end_time, $target, $revolution, $ra, $dec)
	{
		$saa_cold=false;
		$dummy=false;
		if(preg_match("/^saa-cold-/",$target))
			$saa_cold=true;
		if(preg_match("/dummy/i",$target))
			$dummy=true;
// 		$data = array(
// 			'id_satellite' => $id_satellite,
// 			'start_time' => $start_time,
// 			'end_time' => $end_time,
// 			'target' => $target,
// 			'id_observation' => $id_observation,
// 			'revolution' => $revolution,
// 			'ra' => $ra,
// 			'decl' => $dec,
// 		);
// 		return $this->insert($data);
        $db = Zend_Db_Table::getDefaultAdapter();

//         $sql = 'REPLACE INTO events (id_satellite, start_time, end_time, target, id_observation, revolution, ra, decl) values (?, ?, ?, ?, ?, ?, ?, ?)';
//         $stmt = new Zend_Db_Statement_Mysqli($db, $sql);
//         $stmt->execute(array($id_satellite,$id_observation, $start_time, $end_time, $target, $revolution, $ra, $dec));

        $db->query('REPLACE INTO events (id_satellite, start_time, end_time, target, id_observation, revolution, ra, decl,saa_cold,dummy) values (?, ?, ?, ?, ?, ?, ?, ?,?,?)', array($id_satellite, $start_time, $end_time, $target, $id_observation, $revolution, $ra, $dec,($saa_cold?1:0),($dummy?1:0)));
	}

	public function updateEvent($id, $id_satellite, $start_time, $end_time, $target)
	{
		$data = array(
			'id_satellite' => $id_satellite,
			'start_time' => $start_time,
			'end_time' => $end_time,
			'target' => $target
		);
		$this->update($data, 'id = ' .(int)$id);
	}

    public function updateEndtime($id, $end_time)
    {
        $data = array(
            'end_time' => $end_time
        );
        $this->update($data, 'id = ' .(int)$id);
    }

	public function deleteEvent($id)
	{
		$this->delete('id =' . (int)$id);
	}

// 	public function deleteEventsRevolution($id_satellite, $revolution)
// 	{
// 		$this->delete(array('id_satellite =' . (int)$id_satellite, 'revolution =' . (int)$revolution));
// 	}

	public function deleteEventsRevolutions($id_satellite, $startRevolution, $endRevolution)
	{
		$this->delete(array('id_satellite =' . (int)$id_satellite, 'revolution >=' . (int)$startRevolution , 'revolution <=' . (int)$endRevolution));
	}
}