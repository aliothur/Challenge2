<?php
class Model_DbTable_Satellites extends Zend_Db_Table_Abstract
{
	const ID = 'id';
	const STATUS = 'active';
	const NAME = 'name';
	const XML_URL = 'xml_url';
	const CLASS_NAME = 'classname';
	const COLOR = 'color';
	const LAST_REV = 'last_updated';

	protected $_name = 'satellites';
	protected $_rowClass = 'Model_Satellite';
	protected $_dependentTables = array('Model_DbTable_Events');

	public function getSatellite($id)
	{
		$id = (int)$id;
		$row = $this->fetchRow(self::ID.' = ' . $id);
		if(!$row) {
			throw new Exception("Satellite not found");
		}
		return $row;
	}

	public function addSatellite($active, $name, $classname, $xml_url, $last_updated, $color)
	{
		$data = array(
			self::STATUS => $active,
			self::NAME => $name,
			self::XML_URL => $xml_url,
			self::CLASS_NAME => $classname,
			self::COLOR => $color,
			self::LAST_REV => $last_updated
		);
		return $this->insert($data);
	}

	public function updateSatellite($id, $status, $name, $classname, $xml_url, $last_updated, $color)
	{
		$data = array(
			self::STATUS => $status,
			self::NAME => $name,
			self::CLASS_NAME => $classname,
			self::XML_URL => $xml_url,
			self::LAST_REV => $last_updated
		);
		$this->update($data, self::ID.' = ' .(int)$id);
	}

	public function updateSatelliteData($id, $data)
	{
		$this->update($data, self::ID.' = ' .(int)$id);
	}

	public function updateColor($id, $color)
	{
		$data = array(
			self::COLOR => $color
		);
		$this->update($data, self::ID.' = ' .(int)$id);
	}

	public function updateState($id, $state)
	{
		$data = array(
			self::STATUS => $state
		);
		$this->update($data, self::ID.' = ' .(int)$id);
	}

	public function deleteSatellite($id)
	{
		$this->delete(self::ID.' =' . (int)$id);
	}

	public function getSatelliteId($name)
	{
		$select = $this->select()->where(self::NAME.' = "' . (string)$name . '"');
		$row = $this->fetchRow($select);
		if(!$row) {
			throw new Exception("Satellite not found");
		}

		return $row->id;
	}

	public function getSatelliteByName($name)
	{
		$select = $this->select()->where(self::NAME.' = "' . (string)$name . '"');
		$row = $this->fetchRow($select);
		if(!$row) {
			throw new Exception("Satellite not found");
		}

		return $row;
	}
}