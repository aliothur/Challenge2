<?php
class Form_LoginForm extends Zend_Form
{
	public function __construct($option = null) {
		parent::__construct($option);

		$this->setName('login');

		$username = new Zend_Form_Element_Text('username');
		$username->setLabel('Username:')
			 ->setRequired()
			 ->addValidator('alnum');

		$password = new Zend_Form_Element_Password('password');
		$password->setLabel('Password:')
			 ->setRequired();

		$login = new Zend_Form_Element_Submit('login');
		$login->setLabel('Login');

		$captcha = new Zend_Form_Element_Captcha('foo', array(
   			 'label' => "Please verify you're a human:",
			 'captcha' => array(
			        'captcha' => 'Figlet',
			        'wordLen' => 6,
			        'timeout' => 300,
    				),
			));

		$this->addElements(array($username, $password, $captcha, $login));
		$this->setMethod('post');
		$this->setAction(Zend_Controller_Front::getInstance()->getBaseUrl().'/authentication/login');
	}
}
