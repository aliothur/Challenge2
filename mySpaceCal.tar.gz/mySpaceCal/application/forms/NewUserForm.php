<?php
class Form_NewUserForm extends Zend_Form
{
	public function __construct($option = null) {
		parent::__construct($option);

		$this->setName('newuser');

		$username = new Zend_Form_Element_Text('username');
		$username->setLabel('Username:')
			 ->setRequired()
			 ->addValidator('alnum')
			 ->addValidator('stringLength', false, array(1, 50));

		$password = new Zend_Form_Element_Password('password');
		$password->setLabel('Password:')
			 ->setRequired()
			 ->addValidator('stringLength', false, array(5, 255));


                $captcha = new Zend_Form_Element_Captcha('foo', array(
                         'label' => "Please verify you're a human:",
                         'captcha' => array(
                                'captcha' => 'Figlet',
                                'wordLen' => 6,
                                'timeout' => 300,
                                ),
                        ));

		$login = new Zend_Form_Element_Submit('login');
		$login->setLabel('Register');

		$this->addElements(array($username, $password, $captcha, $login));
		$this->setMethod('post');
		$this->setAction(Zend_Controller_Front::getInstance()->getBaseUrl().'/authentication/register');
	}
}
